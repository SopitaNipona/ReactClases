//Autor: Diego Sánchez Valle
import "../styles/puntos.css"

export const Puntos = ({puntos}) => {
    return(
        <div className="puntos-tenis">
            {puntos}
        </div>
    )
};

export default Puntos;