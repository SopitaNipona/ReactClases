import './App.css';
import { Route, Routes } from 'react-router-dom';
import { Home, About, Contact, Products, Events, NotFound } from './components/Paginas';

function App() {
  return (
    <div className="App">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/about" element={<About />} />
        <Route path="/products" element={<Products />} />
        <Route path="/events" element={<Events />} />
        <Route path="/contacts" element={<Contact />} />
        <Route path="*" element={<NotFound />}/>
      </Routes>
    </div>
  );
}

export default App;
